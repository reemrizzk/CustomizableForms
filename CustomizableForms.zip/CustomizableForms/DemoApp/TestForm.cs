﻿using CustomizableForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class TestForm : CustomizableForms.CustomizableForm
    {
        public TestForm()
        {
            InitializeComponent();
            numericUpDown_BorderWidth.Value = (Decimal)this.BorderWidth;
        }

        private void TestForm_Load(object sender, EventArgs e)
        {

        }

        private void radio_Light_CheckedChanged(object sender, EventArgs e)
        {
            if (radio_Light.Checked) this.DarkTheme = false;
        }

        private void radio_Dark_CheckedChanged(object sender, EventArgs e)
        {
            if (radio_Dark.Checked) this.DarkTheme = true;
        }

        private void check_FormResizable_CheckedChanged(object sender, EventArgs e)
        {
            if (check_FormResizable.Checked) this.Resizable = true;
            else this.Resizable = false;
        }

        private void numericUpDown_BorderWidth_ValueChanged(object sender, EventArgs e)
        {
            this.BorderWidth = (int) numericUpDown_BorderWidth.Value;
        }

        private void button_HeaderColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
             {
                formHeader.BackColor = colorDialog1.Color;
             }
        }

        private void button_BorderColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                this.BorderColor = colorDialog1.Color;
            }
        }

        private void button_show1_Click(object sender, EventArgs e)
        {
            FormWithMenuStrip form = new FormWithMenuStrip();
            form.Show();
        }
    }
}
