﻿using CustomizableForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class FormWithMenuStrip : CustomizableForms.CustomizableForm
    {
        public FormWithMenuStrip()
        {
            InitializeComponent();
        }

        private void FormWithMenuStrip_Load(object sender, EventArgs e)
        {

        }
    }
}
