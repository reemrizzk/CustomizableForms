﻿
namespace DemoApp
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.numericUpDown_BorderWidth = new System.Windows.Forms.NumericUpDown();
            this.label_BorderWidth = new System.Windows.Forms.Label();
            this.button_BorderColor = new System.Windows.Forms.Button();
            this.button_HeaderColor = new System.Windows.Forms.Button();
            this.check_FormResizable = new System.Windows.Forms.CheckBox();
            this.radio_Dark = new System.Windows.Forms.RadioButton();
            this.radio_Light = new System.Windows.Forms.RadioButton();
            this.label_HeaderStyle = new System.Windows.Forms.Label();
            this.button_show1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_BorderWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // formHeader
            // 
            this.formHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.formHeader.Size = new System.Drawing.Size(524, 32);
            // 
            // numericUpDown_BorderWidth
            // 
            this.numericUpDown_BorderWidth.Location = new System.Drawing.Point(98, 93);
            this.numericUpDown_BorderWidth.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_BorderWidth.Name = "numericUpDown_BorderWidth";
            this.numericUpDown_BorderWidth.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown_BorderWidth.TabIndex = 15;
            this.numericUpDown_BorderWidth.ValueChanged += new System.EventHandler(this.numericUpDown_BorderWidth_ValueChanged);
            // 
            // label_BorderWidth
            // 
            this.label_BorderWidth.AutoSize = true;
            this.label_BorderWidth.Location = new System.Drawing.Point(17, 95);
            this.label_BorderWidth.Name = "label_BorderWidth";
            this.label_BorderWidth.Size = new System.Drawing.Size(75, 15);
            this.label_BorderWidth.TabIndex = 14;
            this.label_BorderWidth.Text = "Border width";
            // 
            // button_BorderColor
            // 
            this.button_BorderColor.Location = new System.Drawing.Point(20, 158);
            this.button_BorderColor.Name = "button_BorderColor";
            this.button_BorderColor.Size = new System.Drawing.Size(127, 23);
            this.button_BorderColor.TabIndex = 13;
            this.button_BorderColor.Text = "Change border color";
            this.button_BorderColor.UseVisualStyleBackColor = true;
            this.button_BorderColor.Click += new System.EventHandler(this.button_BorderColor_Click);
            // 
            // button_HeaderColor
            // 
            this.button_HeaderColor.Location = new System.Drawing.Point(20, 129);
            this.button_HeaderColor.Name = "button_HeaderColor";
            this.button_HeaderColor.Size = new System.Drawing.Size(127, 23);
            this.button_HeaderColor.TabIndex = 12;
            this.button_HeaderColor.Text = "Change header color";
            this.button_HeaderColor.UseVisualStyleBackColor = true;
            this.button_HeaderColor.Click += new System.EventHandler(this.button_HeaderColor_Click);
            // 
            // check_FormResizable
            // 
            this.check_FormResizable.AutoSize = true;
            this.check_FormResizable.Checked = true;
            this.check_FormResizable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_FormResizable.Location = new System.Drawing.Point(20, 73);
            this.check_FormResizable.Name = "check_FormResizable";
            this.check_FormResizable.Size = new System.Drawing.Size(113, 19);
            this.check_FormResizable.TabIndex = 11;
            this.check_FormResizable.Text = "Form is resizable";
            this.check_FormResizable.UseVisualStyleBackColor = true;
            this.check_FormResizable.CheckedChanged += new System.EventHandler(this.check_FormResizable_CheckedChanged);
            // 
            // radio_Dark
            // 
            this.radio_Dark.AutoSize = true;
            this.radio_Dark.Checked = true;
            this.radio_Dark.Location = new System.Drawing.Point(153, 48);
            this.radio_Dark.Name = "radio_Dark";
            this.radio_Dark.Size = new System.Drawing.Size(49, 19);
            this.radio_Dark.TabIndex = 10;
            this.radio_Dark.TabStop = true;
            this.radio_Dark.Text = "Dark";
            this.radio_Dark.UseVisualStyleBackColor = true;
            this.radio_Dark.CheckedChanged += new System.EventHandler(this.radio_Dark_CheckedChanged);
            // 
            // radio_Light
            // 
            this.radio_Light.AutoSize = true;
            this.radio_Light.Location = new System.Drawing.Point(95, 48);
            this.radio_Light.Name = "radio_Light";
            this.radio_Light.Size = new System.Drawing.Size(52, 19);
            this.radio_Light.TabIndex = 9;
            this.radio_Light.Text = "Light";
            this.radio_Light.UseVisualStyleBackColor = true;
            this.radio_Light.CheckedChanged += new System.EventHandler(this.radio_Light_CheckedChanged);
            // 
            // label_HeaderStyle
            // 
            this.label_HeaderStyle.AutoSize = true;
            this.label_HeaderStyle.Location = new System.Drawing.Point(17, 50);
            this.label_HeaderStyle.Name = "label_HeaderStyle";
            this.label_HeaderStyle.Size = new System.Drawing.Size(72, 15);
            this.label_HeaderStyle.TabIndex = 8;
            this.label_HeaderStyle.Text = "Header style";
            // 
            // button_show1
            // 
            this.button_show1.Location = new System.Drawing.Point(20, 200);
            this.button_show1.Name = "button_show1";
            this.button_show1.Size = new System.Drawing.Size(198, 23);
            this.button_show1.TabIndex = 16;
            this.button_show1.Text = "Show form with menustrip";
            this.button_show1.UseVisualStyleBackColor = true;
            this.button_show1.Click += new System.EventHandler(this.button_show1_Click);
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BorderColor = System.Drawing.Color.RoyalBlue;
            this.Resizable = true;
            this.ClientSize = new System.Drawing.Size(526, 423);
            this.Controls.Add(this.button_show1);
            this.Controls.Add(this.numericUpDown_BorderWidth);
            this.Controls.Add(this.label_BorderWidth);
            this.Controls.Add(this.button_BorderColor);
            this.Controls.Add(this.button_HeaderColor);
            this.Controls.Add(this.check_FormResizable);
            this.Controls.Add(this.radio_Dark);
            this.Controls.Add(this.radio_Light);
            this.Controls.Add(this.label_HeaderStyle);
            this.DarkTheme = true;
            this.Name = "TestForm";
            this.Text = "Test form";
            this.Load += new System.EventHandler(this.TestForm_Load);
            this.Controls.SetChildIndex(this.formHeader, 0);
            this.Controls.SetChildIndex(this.label_HeaderStyle, 0);
            this.Controls.SetChildIndex(this.radio_Light, 0);
            this.Controls.SetChildIndex(this.radio_Dark, 0);
            this.Controls.SetChildIndex(this.check_FormResizable, 0);
            this.Controls.SetChildIndex(this.button_HeaderColor, 0);
            this.Controls.SetChildIndex(this.button_BorderColor, 0);
            this.Controls.SetChildIndex(this.label_BorderWidth, 0);
            this.Controls.SetChildIndex(this.numericUpDown_BorderWidth, 0);
            this.Controls.SetChildIndex(this.button_show1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_BorderWidth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.NumericUpDown numericUpDown_BorderWidth;
        private System.Windows.Forms.Label label_BorderWidth;
        private System.Windows.Forms.Button button_BorderColor;
        private System.Windows.Forms.Button button_HeaderColor;
        private System.Windows.Forms.CheckBox check_FormResizable;
        private System.Windows.Forms.RadioButton radio_Dark;
        private System.Windows.Forms.RadioButton radio_Light;
        private System.Windows.Forms.Label label_HeaderStyle;
        private System.Windows.Forms.Button button_show1;
    }
}